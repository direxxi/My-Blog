<?php
declare(strict_types=1);
require_once 'configsesh.inc.php';


function getPost(object $pdo, int $user_id){

$query = 'SELECT id FROM posts WHERE users_id = :user_id;';
$prpd_stmt = $pdo->prepare($query);
$prpd_stmt -> bindParam(':user_id',$user_id);
$prpd_stmt->execute();
$result = $prpd_stmt->fetch(PDO::FETCH_ASSOC);
return $result['id'];
}



function postComments(object $pdo, string $comment, int $user_id, int $post_id){
    $query = 'INSERT INTO comments(comment_text,user_id,post_id) VALUES(:comment,:user_id,:post_id);';
    $prpd_stmt = $pdo -> prepare($query);
    $prpd_stmt -> bindParam(':comment',$comment);
    $prpd_stmt -> bindParam(':user_id',$user_id);
    $prpd_stmt -> bindParam(':post_id', $post_id);
    
    $prpd_stmt -> execute();
}

function viewAllComments(object $pdo,int $post_id) {
    $query = 'SELECT comments.comment_text, comments.created_at, users.username 
              FROM comments 
              JOIN users ON comments.user_id = users.id
              JOIN posts ON comments.post_id = posts.id;
              WHERE commments.post_id = :post_id;';
              
              
              
    $prpd_stmt = $pdo->prepare($query);
    $prpd_stmt -> bindParam(':post_id',$post_id,PDO::PARAM_INT);
    $prpd_stmt->execute();

    // Use fetchAll to get all comments instead of a single row
    $post_comments = $prpd_stmt->fetchAll(PDO::FETCH_ASSOC);
    return $post_comments;
}

function getCommentCount(object $pdo): int {
    $query = 'SELECT COUNT(*) AS total_comments FROM comments';
    $prpd_stmt = $pdo->prepare($query);
    $prpd_stmt->execute();
    
    $result = $prpd_stmt->fetch(PDO::FETCH_ASSOC);
    return (int) $result['total_comments']; // Cast to integer
}


